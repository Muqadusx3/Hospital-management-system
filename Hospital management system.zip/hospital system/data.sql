
INSERT INTO Dept (dept_id, dept_name, hospital_id,total_emp)
VALUES (1, 'Child', 1,0),
       (2, 'ENT', 1,0),
       (3, 'Eyes', 1,0),
       (4, 'Skin', 1,0),
       (5, 'Orthopaedic', 1,0),
	   (6, 'Child', 2,0),
       (7, 'ENT', 2,0),
       (8, 'Eyes', 2,0),
       (9, 'Skin', 2,0),
       (10, 'Orthopaedic', 2,0);

INSERT INTO emp (emp_id, e_name, age, gender, e_address, phone_no, dept_id)
VALUES 
  (1, 'John Smith', 30, 'Male', '123 Main Street', 123456789, 1),
  (2, 'Jane Doe', 35, 'Female', '456 Elm Street', 987654321, 2),
  (3, 'Michael Johnson', 28, 'Male', '789 Oak Avenue', 234567890, 3),
  (4, 'Emily Davis', 32, 'Female', '321 Pine Road', 890123456, 4),
  (5, 'Christopher Brown', 27, 'Male', '567 Maple Lane', 345678901, 5),
  (6, 'Jessica Wilson', 29, 'Female', '901 Cedar Avenue', 678901234, 1),
  (7, 'Matthew Anderson', 31, 'Male', '234 Elm Street', 901234567, 2),
  (8, 'Sophia Taylor', 34, 'Female', '678 Oak Avenue', 123456789, 3),
  (9, 'Daniel Martinez', 33, 'Male', '123 Pine Road', 456789012, 4),
  (10, 'Olivia Johnson', 26, 'Female', '456 Maple Lane', 789012345, 5),
  (11, 'Andrew Thomas', 30, 'Male', '789 Cedar Avenue', 123450987, 1),
  (12, 'Emma Rodriguez', 28, 'Female', '901 Elm Street', 234567890, 2),
  (13, 'William Garcia', 32, 'Male', '234 Oak Avenue', 345678901, 3),
  (14, 'Ava Lopez', 31, 'Female', '567 Pine Road', 456789012, 4),
  (15, 'James Martinez', 29, 'Male', '901 Maple Lane', 567890123, 5),
  (16, 'Isabella Hernandez', 27, 'Female', '234 Cedar Avenue', 678901234, 1),
  (17, 'Benjamin Gonzalez', 33, 'Male', '567 Elm Street', 789012345, 2),
  (18, 'Mia Wilson', 30, 'Female', '901 Oak Avenue', 890123456, 3 ),
  (19, 'Henry Thompson', 28, 'Male', '234 Pine Road', 901234567, 4),
  (20, 'Charlotte Young', 26, 'Female', '567 Maple Lane', 123456789, 5);

  INSERT INTO doctor (emp_id, specilist, room_no)
VALUES 
  (1, 'Cardiologist', 101),
  (2, 'Neurologist', 102),
  (3, 'Ophthalmologist', 103),
  (4, 'Dermatologist', 104),
  (5, 'Orthopedic Surgeon', 105),
  (6, 'Pediatrician', 106),
  (7, 'ENT Specialist', 201),
  (8, 'Gynecologist', 202),
  (9, 'Psychiatrist', 203),
  (10, 'General Surgeon', 204);

INSERT INTO room_p (catagory, price)
VALUES 
  ('doctor_room',0),
  ('lower', 1000),
  ('middle', 1500),
  ('high', 2000);



INSERT INTO room (room_no, dept_id, status, catagory)
VALUES 
  (101, 1, 'Available', 'doctor_room'),
  (102, 2, 'Occupied', 'doctor_room'),
  (103, 3, 'Available', 'doctor_room'),
  (104, 1, 'Occupied', 'doctor_room'),
  (105, 2, 'Available', 'doctor_room'),
  (106, 3, 'Occupied', 'doctor_room'),
  (201, 1, 'Available', 'doctor_room'),
  (202, 2, 'Occupied', 'doctor_room'),
  (203, 3, 'Available', 'doctor_room'),
  (204, 1, 'Occupied', 'doctor_room'),
  (205, 2, 'Available', 'high'),
  (206, 3, 'Occupied', 'lower'),
  (301, 1, 'Available', 'middle'),
  (302, 2, 'Occupied', 'middle'),
  (303, 3, 'Available', 'middle'),
  (304, 1, 'Occupied', 'lower'),
  (305, 2, 'Available', 'high'),
  (306, 3, 'Occupied', 'high'),
  (401, 1, 'Available', 'lower'),
  (402, 2, 'Occupied', 'middle');

  INSERT INTO patient (patient_id, pname, gender, paddress, age, phone_no)
VALUES 
  (1, 'John Smith', 'Male', '123 Main St, City', 30, 123456789),
  (2, 'Emily Johnson', 'Female', '456 Elm St, City', 25, 987654321),
  (3, 'Michael Davis', 'Male', '789 Oak St, City', 45, 456789123),
  (4, 'Emma Wilson', 'Female', '321 Pine St, City', 35, 789123456),
  (5, 'Daniel Brown', 'Male', '654 Cedar St, City', 50, 654987321),
  (6, 'Olivia Taylor', 'Female', '987 Maple St, City', 28, 321654987),
  (7, 'James Anderson', 'Male', '852 Walnut St, City', 42, 852741963),
  (8, 'Sophia Clark', 'Female', '159 Birch St, City', 37, 369258147),
  (9, 'Alexander Walker', 'Male', '753 Pine St, City', 31, 147258369),
  (10, 'Ava Turner', 'Female', '456 Oak St, City', 29, 963852741);

  INSERT INTO insurance_cover (ins_code, ins_company, medical_coverage)
VALUES 
  (1, 'ABC Insurance', 80000),
  (2, 'XYZ Insurance', 70000),
  (3, 'DEF Insurance', 90000),
  (4, 'GHI Insurance', 75000),
  (5, 'JKL Insurance', 85000),
  (6, 'MNO Insurance', 95000);


 INSERT INTO Insurance (ins_no, patient_id, maternity, optical, dental, ins_code, remaing_med_amount, expire_date)
VALUES
    (1, 1, 'Yes', 'No', 'Yes', 1, 50000, '2023-12-31'),
    (2, 2, 'No', 'Yes', 'No', 2, 10000, '2024-06-30'),
    (3, 3, 'Yes', 'Yes', 'Yes', 3, 50000, '2023-10-15'),
    (4, 4, 'No', 'No', 'No', 4, 75000, '2024-02-28'),
    (5, 5, 'No', 'Yes', 'Yes', 5, 20000, '2023-11-30'),
    (6, 6, 'Yes', 'Yes', 'No', 6, 10000, '2024-04-15'),
    (7, 9, 'No', 'Yes', 'No', 1, 50000, '2024-05-15'),
    (8, 10, 'Yes', 'No', 'Yes', 2, 10000, '2023-10-31');

INSERT INTO Bill (bill_no, patient_id, dec_charge, med_charge, room_charge, nursing_charge, lab_charge, advance, ins_no, ins_patient_id,total)
VALUES 
  (1, 1, 500, 1000, 0, 200, 0, 500, 1, 1,0),
  (2, 2, 600, 800, 0, 250, 0, 400, 2, 2,0),
  (3, 3, 700, 1200, 0, 0, 400, 300, 3, 3,0),
  (4, 4, 400, 900, 0, 150, 0, 600, 4, 4,0),
  (5, 5, 800, 1100, 0, 350, 0, 700, 5, 5,0),
  (6, 6, 600, 1000, 0, 0, 0, 500, 6, 6,0),
  (7, 7, 700, 1200, 0, 0, 0, 300, null, null,0),
  (8, 8, 500, 900, 0, 0, 0, 600, null,null,0),
  (9, 9, 800, 1100, 0, 0, 0, 700, 7, 9,0),
  (10, 10, 400, 800,  0, 0, 0, 500, 8,10 ,0);

  INSERT INTO nurse (emp_id, shift_t)
VALUES 
  (11, 'Morning'),
  (12, 'Evening'),
  (13, 'Night'),
  (14, 'Morning'),
  (15, 'Evening');
  INSERT INTO payroll (payroll_id, emp_id, salary, bouns, account_no)
VALUES 
  (1, 1, 50000, 1000, 123456789),
  (2, 2, 60000, 1200, 987654321),
  (3, 3, 55000, 800, 456789123),
  (4, 4, 48000, 600, 789123456),
  (5, 5, 52000, 900, 321654987),
  (6, 6, 45000, 700, 654987321),
  (7, 7, 48000, 800, 159263487),
  (8, 8, 52000, 1000, 987654321),
  (9, 9, 55000, 1200, 456789123),
  (10, 10, 60000, 900, 321654987),
  (11, 11, 5000, 1000, 123456789),
  (12, 12, 6000, 1200, 987654321),
  (13, 13, 5500, 800, 456789123),
  (14, 14, 4800, 600, 789123456),
  (15, 15, 5200, 900, 321654987),
  (16, 16, 4500, 700, 654987321),
  (17, 17, 4800, 800, 159263487),
  (18, 18, 5200, 1000, 987654321),
  (19, 19, 5500, 1200, 456789123),
  (20, 20, 6000, 900, 321654987);

INSERT INTO Supplier (Supplier_Id, Supplier_name, phone, email, address, status)
VALUES
    (1, 'ABC Supplier', '1234567890', 'abc@example.com', '123 Main Street, City', 'Active'),
    (2, 'XYZ Supplier', '9876543210', 'xyz@example.com', '456 Elm Street, City', 'Active'),
    (3, 'PQR Supplier', '1112223333', 'pqr@example.com', '789 Oak Street, City', 'Inactive'),
    (4, 'LMN Supplier', '4445556666', 'lmn@example.com', '789 Maple Street, City', 'Active'),
	(5, 'MNO Suppliers', '6549873210', 'mno@example.com', '987 Maple Street','Active');

INSERT INTO Medicine (med_Id, med_name, med_type, med_desc, med_price,stock)
VALUES
  (1, 'Medicine A', 'Tablet', 'Description of Medicine A', 10,200),
  (2, 'Medicine B', 'Capsule', 'Description of Medicine B', 15,150),
  (3, 'Medicine C', 'Syrup', 'Description of Medicine C', 20,180),
  (4, 'Medicine D', 'Injection', 'Description of Medicine D', 25,250),
  (5, 'Medicine E', 'Ointment', 'Description of Medicine E', 30,220),
  (6, 'Medicine F', 'Drops', 'Description of Medicine F', 35,110),
  (7, 'Medicine G', 'Inhaler', 'Description of Medicine G', 40,170),
  (8, 'Medicine H', 'Pill', 'Description of Medicine H', 45,240),
  (9, 'Medicine I', 'Cream', 'Description of Medicine I', 50,80),
  (10, 'Medicine J', 'Solution', 'Description of Medicine J', 55,200);

INSERT INTO Medicine_report (med_report_id, med_Id, company, quantity, box, prod_date, expire_date, country, supplier_Id)
VALUES
  (1, 1, 'Company A', 100, 5, '2023-06-20', '2024-06-20', 'Country A', 1),
  (2, 2, 'Company B', 150, 3, '2023-06-21', '2024-06-21', 'Country B', 2),
  (3, 3, 'Company C', 200, 7, '2023-06-22', '2024-06-22', 'Country C', 3),
  (4, 4, 'Company D', 120, 2, '2023-06-23', '2024-06-23', 'Country D', 4),
  (5, 5, 'Company E', 180, 4, '2023-06-24', '2024-06-24', 'Country E', 5),
  (6, 6, 'Company F', 130, 6, '2023-06-25', '2024-06-25', 'Country F', 1),
  (7, 7, 'Company G', 160, 8, '2023-06-26', '2024-06-26', 'Country G', 2),
  (8, 8, 'Company H', 140, 9, '2023-06-27', '2024-06-27', 'Country H', 3),
  (9, 9, 'Company I', 170, 5, '2023-06-28', '2024-06-28', 'Country I', 4),
  (10, 10, 'Company J', 110, 3, '2023-06-29', '2024-06-29', 'Country J', 5);

INSERT INTO Patient_Report (report_Id, patient_Id, diagnosis, reference)
VALUES
  (1, 1, 'Diagnosis A', 'Reference A'),
  (2, 2, 'Diagnosis B', 'Reference B'),
  (3, 3, 'Diagnosis C', 'Reference C'),
  (4, 4, 'Diagnosis D', 'Reference D'),
  (5, 5, 'Diagnosis E', 'Reference E'),
  (6, 6, 'Diagnosis F', 'Reference F'),
  (7, 7, 'Diagnosis G', 'Reference G'),
  (8, 8, 'Diagnosis H', 'Reference H'),
  (9, 9, 'Diagnosis I', 'Reference I'),
  (10, 10, 'Diagnosis J', 'Reference J');

INSERT INTO Prescribed_Med (Pres_med_Id, Patient_Id, Med_id, Report_id,quantity)
VALUES
  (1, 1, 1, 1,10),
  (2, 2, 2, 2,2),
  (3, 3, 3, 3,8),
  (4, 4, 4, 4,12),
  (5, 5, 5, 5,5),
  (6, 6, 6, 6,1),
  (7, 7, 7, 7,4),
  (8, 8, 8, 8,10),
  (9, 9, 9, 9,6),
  (10, 10, 10, 10,7);

INSERT INTO test_p (test_code, t_price)
VALUES
  (01, 100),
  (02, 150),
  (03, 200),
  (04, 120),
  (05, 180),
  (06, 250),
  (07, 300);


  INSERT INTO appointment (patient_id, appointment_id, date, doctor_id)
VALUES
  (1, 1, '2023-06-21 10:00:00', 1),
  (2, 2, '2023-06-22 14:30:00', 2),
  (3, 3, '2023-06-23 11:15:00', 3),
  (4, 4, '2023-06-24 09:45:00', 4),
  (5, 5, '2023-06-25 16:00:00', 5),
  (6, 6, '2023-06-26 13:30:00', 6),
  (7, 7, '2023-06-27 15:45:00', 7),
  (8, 8, '2023-06-28 10:30:00', 8),
  (9, 9, '2023-06-29 12:00:00', 9),
  (10, 10, '2023-06-30 14:15:00', 10);

INSERT INTO admission (admission_id, patient_id, doctor_id, nurse_id, room_no, date, stay)
VALUES
  (1, 1, 1, 11, 301, '2023-06-21 10:00:00', 3),
  (2, 2, 2, 12, 302, '2023-06-22 14:30:00', 4),
  (3, 3, 3, 13, 303, '2023-06-23 11:15:00', 5),
  (4, 4, 4, 14, 304, '2023-06-24 09:45:00', 2),
  (5, 5, 5, 15, 305, '2023-06-25 16:00:00', 7);

INSERT INTO lab (lab_no, patient_id, test_type, high, wight, date, b_p_up,b_p_down, temp, test_code, nurse_id)
VALUES
(1, 1, 1, 120, 65, '2023-06-01', 120,80, 98.6, 01, 11),
(2, 2, 2, 130, 70, '2023-06-02', 130,85, 99.2, 02, 12),
(3, 3, 1, 125, 68, '2023-06-03', 118,78, 98.4, 01, 13),
(4, 4, 3, 140, 75, '2023-06-04', 135,90, 99.8, 03, 14),
(5, 5, 2, 128, 72, '2023-06-05', 122,82, 98.9, 02, 15),
(6, 6, 1, 122, 66, '2023-06-06', 116,76, 98.1, 01, 11),
(7, 8, 2, 132, 73, '2023-06-07', 128,84, 99.5, 02, 12),
(8, 10, 3, 138, 74, '2023-06-08', 133,88, 99.7, 03, 13);








