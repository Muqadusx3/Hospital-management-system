CREATE VIEW vw_employee_info AS
SELECT e.emp_id, e.e_name, e.age, e.gender, e.e_address, e.phone_no, d.dept_name AS department
FROM emp e
JOIN dept d ON e.dept_id = d.dept_id;

CREATE VIEW vw_payroll_info AS
SELECT p.payroll_id, p.emp_id, e.e_name, p.salary, p.bouns, p.account_no
FROM payroll p
JOIN emp e ON p.emp_id = e.emp_id;

CREATE VIEW vw_room_info AS
SELECT r.room_no, r.dept_id, r.status, rp.catagory, rp.price
FROM room r
JOIN room_p rp ON r.catagory = rp.catagory;

CREATE VIEW vw_lab_info AS
SELECT l.lab_no, p.patient_id, p.pname, l.test_type, l.high, l.wight, l.date, l.b_p_up,L.b_p_down, l.temp, tp.test_code,l.status, n.emp_id AS nurse_id, n.shift_t
FROM lab l
JOIN patient p ON l.patient_id = p.patient_id
JOIN test_p tp ON l.test_code = tp.test_code
JOIN nurse n ON l.nurse_id = n.emp_id;

CREATE VIEW vw_doctor_info AS
SELECT d.emp_id, e.e_name, d.specilist, r.room_no
FROM doctor d
JOIN emp e ON d.emp_id = e.emp_id
JOIN room r ON d.room_no = r.room_no;

CREATE VIEW vw_appointment_info AS
SELECT a.patient_id, p.pname, a.appointment_id, a.date, d.emp_id AS doctor_id, e.e_name
FROM appointment a
JOIN patient p ON a.patient_id = p.patient_id
JOIN doctor d ON a.doctor_id = d.emp_id
join emp e on d.emp_id=e.emp_id;

CREATE VIEW vw_insurance_info AS
SELECT i.ins_no, i.patient_id, p.pname, i.maternity, i.optical, i.dental, ic.ins_code, ic.ins_company, ic.medical_coverage
FROM insurance i
JOIN patient p ON i.patient_id = p.patient_id
JOIN insurance_cover ic ON i.ins_code = ic.ins_code;

CREATE VIEW vw_admission_info AS
SELECT ad.admission_id, ad.patient_id, p.pname, ad.doctor_id AS doctor_id,e.e_name as doctor_name
, ad.nurse_id as nurse_id,en.e_name as nurse_name, ad.room_no, ad.date, ad.stay
FROM admission ad
JOIN patient p ON ad.patient_id = p.patient_id
JOIN doctor d ON ad.doctor_id = d.emp_id
join emp e on e.emp_id=d.emp_id
JOIN nurse n ON ad.nurse_id = n.emp_id
join emp en on en.emp_id=n.emp_id;

CREATE VIEW Bill_View AS
SELECT b.bill_no, b.patient_id, p.pname, b.dec_charge, b.med_charge, b.room_charge, 
      b.nursing_charge, b.lab_charge, b.advance, i.ins_no, i.maternity, i.optical, i.dental,b.total
FROM Bill b
JOIN Patient p ON b.patient_id = p.patient_id
LEFT JOIN Insurance i ON b.ins_no = i.ins_no AND b.ins_patient_id = i.patient_id;


CREATE VIEW Insurance_View AS
SELECT i.ins_no, i.patient_id, p.pname, i.maternity, i.optical, i.dental, ic.ins_company, ic.medical_coverage
FROM Insurance i
JOIN Patient p ON i.patient_id = p.patient_id
JOIN Insurance_Cover ic ON i.ins_code = ic.ins_code;

CREATE VIEW Lab_View AS
SELECT l.lab_no, l.patient_id, p.pname, l.test_type, l.high, l.wight, l.date, l.b_p_up,L.b_p_down, l.temp,
       l.test_code, tp.t_price,l.status, l.nurse_id, E.e_name AS nurse_name
FROM Lab l
JOIN Patient p ON l.patient_id = p.patient_id
JOIN Test_P tp ON l.test_code = tp.test_code
JOIN Nurse n ON l.nurse_id = n.emp_id
JOIN EMP E ON N.emp_id=E.emp_id;

CREATE VIEW Room_View AS
SELECT r.room_no, r.dept_id, d.dept_name, r.status, r.catagory, rp.price
FROM Room r
JOIN Dept d ON r.dept_id = d.dept_id
JOIN Room_P rp ON r.catagory = rp.catagory;

CREATE VIEW Test_Price_View AS
SELECT test_code, t_price
FROM Test_P;

CREATE VIEW Nurse_Assignment_View AS
SELECT L.nurse_id, E.e_name AS nurse_name, 'Lab' AS assignment_type
FROM LAB L
JOIN EMP E ON E.emp_id = l.nurse_id

UNION

SELECT A.nurse_id, E.e_name AS nurse_name, 'Admission' AS assignment_type
FROM admission A
JOIN EMP E ON E.emp_id = a.nurse_id;

CREATE VIEW EmployeeDetails AS
SELECT emp.emp_id, emp.e_name, emp.age, emp.gender, emp.e_address, emp.phone_no,
       dept.dept_name,
       CASE
           WHEN doctor.emp_id IS NOT NULL THEN 'Doctor'
           WHEN nurse.emp_id IS NOT NULL THEN 'Nurse'
           ELSE 'Other Employee'
       END AS employee_type
FROM emp
INNER JOIN dept ON emp.dept_id = dept.dept_id
LEFT JOIN doctor ON emp.emp_id = doctor.emp_id
LEFT JOIN nurse ON emp.emp_id = nurse.emp_id;

CREATE VIEW PatientDetails AS
SELECT p.patient_id, p.pname, p.gender, p.paddress, p.age, p.phone_no,
       a.admission_id, a.doctor_id, a.nurse_id, a.room_no, a.date AS admission_date, a.stay,
       ap.appointment_id, ap.date AS appointment_date,
       l.lab_no, l.test_type, l.high, l.wight, l.date AS lab_date, l.temp
FROM patient p
LEFT JOIN admission a ON p.patient_id = a.patient_id
LEFT JOIN appointment ap ON p.patient_id = ap.patient_id
LEFT JOIN lab l ON p.patient_id = l.patient_id;

