USE [master]
GO
/****** Object:  Database [hp]    Script Date: 6/22/2023 7:19:53 PM ******/
CREATE DATABASE [hp]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'hp', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\hp.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'hp_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\hp_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [hp] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [hp].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [hp] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [hp] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [hp] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [hp] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [hp] SET ARITHABORT OFF 
GO
ALTER DATABASE [hp] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [hp] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [hp] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [hp] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [hp] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [hp] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [hp] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [hp] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [hp] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [hp] SET  DISABLE_BROKER 
GO
ALTER DATABASE [hp] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [hp] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [hp] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [hp] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [hp] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [hp] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [hp] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [hp] SET RECOVERY FULL 
GO
ALTER DATABASE [hp] SET  MULTI_USER 
GO
ALTER DATABASE [hp] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [hp] SET DB_CHAINING OFF 
GO
ALTER DATABASE [hp] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [hp] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [hp] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [hp] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'hp', N'ON'
GO
ALTER DATABASE [hp] SET QUERY_STORE = ON
GO
ALTER DATABASE [hp] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [hp]
GO
/****** Object:  UserDefinedFunction [dbo].[GetAvailableRoomsByCategory]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetAvailableRoomsByCategory]
    (@categoryName VARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @availableRooms INT

    SELECT @availableRooms = COUNT(*)
    FROM room
    WHERE catagory = @categoryName AND status = 'Available'

    RETURN @availableRooms
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetDoctorDepartment]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetDoctorDepartment]
    (@doctorID INT)
RETURNS VARCHAR(50)
AS
BEGIN
    DECLARE @department VARCHAR(50)

    SELECT @department = dept_name
    FROM Dept
    JOIN emp e ON Dept.dept_id = e.dept_id
	join doctor d on e.emp_id=d.emp_id
    WHERE d.emp_id = @doctorID

    RETURN @department
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetDoctorSpecialization]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetDoctorSpecialization]
    (@doctorID INT)
RETURNS VARCHAR(50)
AS
BEGIN
    DECLARE @specialization VARCHAR(50)

    SELECT @specialization = specilist
    FROM Doctor
    WHERE emp_id = @doctorID

    RETURN @specialization
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetMedicinePrice]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetMedicinePrice]
    (@medicineID INT)
RETURNS INT
AS
BEGIN
    DECLARE @price INT

    SELECT @price = med_price
    FROM Medicine
    WHERE med_Id = @medicineID

    RETURN @price
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetRoomCategoryPrice]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetRoomCategoryPrice]
    (@categoryName VARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @price INT

    SELECT @price = price
    FROM room_p
    WHERE catagory = @categoryName

    RETURN @price
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalAdmissionsByDate]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetTotalAdmissionsByDate]
    (@date DATE)
RETURNS INT
AS
BEGIN
    DECLARE @totalCount INT

    SELECT @totalCount = COUNT(*)
    FROM Admission
    WHERE CONVERT(DATE, date) = @date

    RETURN @totalCount
END
GO
/****** Object:  UserDefinedFunction [dbo].[GetTotalPatientsInDepartment]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetTotalPatientsInDepartment]
    (@departmentName VARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @totalCount INT

    SELECT @totalCount = COUNT(DISTINCT patient_id)
    FROM Admission
    JOIN Doctor ON Admission.doctor_id = Doctor.emp_id
	join emp e on e.emp_id=doctor.emp_id
    JOIN Dept ON e.dept_id = Dept.dept_id
    WHERE Dept.dept_name = @departmentName

    RETURN @totalCount
END
GO
/****** Object:  Table [dbo].[patient]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[patient](
	[patient_id] [int] NOT NULL,
	[pname] [varchar](50) NULL,
	[gender] [varchar](10) NULL,
	[paddress] [varchar](100) NULL,
	[age] [int] NULL,
	[phone_no] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[patient_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[insurance_cover]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[insurance_cover](
	[ins_code] [int] NOT NULL,
	[ins_company] [varchar](50) NULL,
	[medical_coverage] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[ins_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[insurance]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[insurance](
	[ins_no] [int] NOT NULL,
	[patient_id] [int] NOT NULL,
	[maternity] [varchar](10) NULL,
	[optical] [varchar](10) NULL,
	[dental] [varchar](10) NULL,
	[ins_code] [int] NULL,
	[remaing_med_amount] [int] NULL,
	[expire_date] [smalldatetime] NULL,
 CONSTRAINT [pk1] PRIMARY KEY CLUSTERED 
(
	[ins_no] ASC,
	[patient_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Insurance_View]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Insurance_View] AS
SELECT i.ins_no, i.patient_id, p.pname, i.maternity, i.optical, i.dental, ic.ins_company, ic.medical_coverage
FROM Insurance i
JOIN Patient p ON i.patient_id = p.patient_id
JOIN Insurance_Cover ic ON i.ins_code = ic.ins_code;
GO
/****** Object:  Table [dbo].[test_p]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[test_p](
	[test_code] [int] NOT NULL,
	[t_price] [int] NULL,
 CONSTRAINT [pk_t] PRIMARY KEY CLUSTERED 
(
	[test_code] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Test_Price_View]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Test_Price_View] AS
SELECT test_code, t_price
FROM Test_P;
GO
/****** Object:  Table [dbo].[emp]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[emp](
	[emp_id] [int] NOT NULL,
	[e_name] [varchar](50) NULL,
	[age] [int] NULL,
	[gender] [varchar](10) NULL,
	[e_address] [varchar](100) NULL,
	[phone_no] [int] NULL,
	[dept_id] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[emp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[lab]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[lab](
	[lab_no] [int] NOT NULL,
	[patient_id] [int] NOT NULL,
	[test_type] [int] NULL,
	[high] [int] NULL,
	[wight] [int] NULL,
	[date] [date] NULL,
	[temp] [int] NULL,
	[test_code] [int] NULL,
	[nurse_id] [int] NULL,
	[status] [varchar](10) NULL,
	[b_p_up] [int] NULL,
	[b_p_down] [int] NULL,
 CONSTRAINT [pk_l] PRIMARY KEY CLUSTERED 
(
	[lab_no] ASC,
	[patient_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[admission]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[admission](
	[admission_id] [int] NOT NULL,
	[patient_id] [int] NOT NULL,
	[doctor_id] [int] NULL,
	[nurse_id] [int] NULL,
	[room_no] [int] NULL,
	[date] [smalldatetime] NULL,
	[stay] [int] NULL,
 CONSTRAINT [pk_a] PRIMARY KEY CLUSTERED 
(
	[patient_id] ASC,
	[admission_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Nurse_Assignment_View]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Nurse_Assignment_View] AS
SELECT L.nurse_id, E.e_name AS nurse_name, 'Lab' AS assignment_type
FROM LAB L
JOIN EMP E ON E.emp_id = l.nurse_id

UNION

SELECT A.nurse_id, E.e_name AS nurse_name, 'Admission' AS assignment_type
FROM admission A
JOIN EMP E ON E.emp_id = a.nurse_id;
GO
/****** Object:  Table [dbo].[doctor]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[doctor](
	[emp_id] [int] NOT NULL,
	[specilist] [varchar](50) NULL,
	[room_no] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[emp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[appointment]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[appointment](
	[patient_id] [int] NOT NULL,
	[appointment_id] [int] NOT NULL,
	[date] [smalldatetime] NULL,
	[doctor_id] [int] NULL,
 CONSTRAINT [pk_p] PRIMARY KEY CLUSTERED 
(
	[patient_id] ASC,
	[appointment_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [dbo].[GetAppointmentDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetAppointmentDetails] (@inputDate DATE, @doctorName VARCHAR(50))
RETURNS TABLE
AS
RETURN
(
  SELECT appointment_id, date, patient_id
  FROM appointment
  WHERE date = @inputDate
    AND doctor_id IN (
      SELECT d.emp_id
      FROM doctor d 
	  join emp e on d.emp_id=e.emp_id
      WHERE e.e_name = @doctorName
    )
);
GO
/****** Object:  UserDefinedFunction [dbo].[GetAppointmentDetails1]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetAppointmentDetails1] (@inputDate smallDATEtime, @doctorName VARCHAR(50))
RETURNS TABLE
AS
RETURN
(
  SELECT appointment_id, date, patient_id
  FROM appointment
  WHERE date = @inputDate
    AND doctor_id IN (
      SELECT d.emp_id
      FROM doctor d 
	  join emp e on d.emp_id=e.emp_id
      WHERE e.e_name = @doctorName
    )
);
GO
/****** Object:  UserDefinedFunction [dbo].[GetAppointmentDetails_patient]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetAppointmentDetails_patient](@patientId INT, @appointmentId INT)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM appointment
    WHERE patient_id = @patientId AND appointment_id = @appointmentId
);
GO
/****** Object:  Table [dbo].[Dept]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Dept](
	[dept_id] [int] NOT NULL,
	[dept_name] [varchar](50) NULL,
	[hospital_id] [int] NULL,
	[total_emp] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[dept_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[nurse]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[nurse](
	[emp_id] [int] NOT NULL,
	[shift_t] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[emp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[EmployeeDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[EmployeeDetails] AS
SELECT emp.emp_id, emp.e_name, emp.age, emp.gender, emp.e_address, emp.phone_no,
       dept.dept_name,
       CASE
           WHEN doctor.emp_id IS NOT NULL THEN 'Doctor'
           WHEN nurse.emp_id IS NOT NULL THEN 'Nurse'
           ELSE 'Other Employee'
       END AS employee_type
FROM emp
INNER JOIN dept ON emp.dept_id = dept.dept_id
LEFT JOIN doctor ON emp.emp_id = doctor.emp_id
LEFT JOIN nurse ON emp.emp_id = nurse.emp_id;
GO
/****** Object:  UserDefinedFunction [dbo].[GetAppointmentsByDate]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetAppointmentsByDate](@appointmentDate DATE)
RETURNS TABLE
AS
RETURN
    SELECT a.appointment_id, a.patient_id, p.pname, a.date, a.doctor_id
    FROM Appointment a
    JOIN Patient p ON a.patient_id = p.patient_id
    WHERE CONVERT(DATE, a.date) = @appointmentDate;
GO
/****** Object:  UserDefinedFunction [dbo].[GetDoctorAppointments]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetDoctorAppointments](@doctorName VARCHAR(50))
RETURNS TABLE
AS
RETURN
    SELECT a.appointment_id, a.patient_id, p.pname, a.date
    FROM Appointment a
    JOIN Patient p ON a.patient_id = p.patient_id
    JOIN Doctor d ON a.doctor_id = d.emp_id
	join emp e on d.emp_id=e.emp_id
    WHERE e.e_name = @doctorName;
GO
/****** Object:  Table [dbo].[room]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[room](
	[room_no] [int] NOT NULL,
	[dept_id] [int] NULL,
	[status] [varchar](50) NULL,
	[catagory] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[room_no] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  UserDefinedFunction [dbo].[GetPatientDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetPatientDetails](@patientID INT)
RETURNS TABLE
AS
RETURN
    SELECT a.appointment_id, a.date AS appointment_date, d.emp_id AS doctor_id, e.e_name AS doctor_name,
           ad.admission_id, ad.date AS admission_date, ad.room_no
    FROM Appointment a
    LEFT JOIN Admission ad ON a.patient_id = ad.patient_id
    LEFT JOIN Doctor d ON a.doctor_id = d.emp_id
	join emp e on e.emp_id=d.emp_id
    LEFT JOIN Room r ON ad.room_no = r.room_no
    WHERE a.patient_id = @patientID;
GO
/****** Object:  View [dbo].[vw_employee_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_employee_info] AS
SELECT e.emp_id, e.e_name, e.age, e.gender, e.e_address, e.phone_no, d.dept_name AS department
FROM emp e
JOIN dept d ON e.dept_id = d.dept_id;
GO
/****** Object:  Table [dbo].[payroll]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[payroll](
	[payroll_id] [int] NOT NULL,
	[emp_id] [int] NOT NULL,
	[salary] [int] NULL,
	[bouns] [int] NULL,
	[account_no] [int] NULL,
 CONSTRAINT [pk] PRIMARY KEY CLUSTERED 
(
	[payroll_id] ASC,
	[emp_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_payroll_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_payroll_info] AS
SELECT p.payroll_id, p.emp_id, e.e_name, p.salary, p.bouns, p.account_no
FROM payroll p
JOIN emp e ON p.emp_id = e.emp_id;
GO
/****** Object:  Table [dbo].[room_p]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[room_p](
	[catagory] [varchar](50) NOT NULL,
	[price] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[catagory] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[vw_room_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_room_info] AS
SELECT r.room_no, r.dept_id, r.status, rp.catagory, rp.price
FROM room r
JOIN room_p rp ON r.catagory = rp.catagory;
GO
/****** Object:  View [dbo].[vw_lab_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_lab_info] AS
SELECT l.lab_no, p.patient_id, p.pname, l.test_type, l.high, l.wight, l.date, l.b_p_up,L.b_p_down, l.temp, tp.test_code,l.status, n.emp_id AS nurse_id, n.shift_t
FROM lab l
JOIN patient p ON l.patient_id = p.patient_id
JOIN test_p tp ON l.test_code = tp.test_code
JOIN nurse n ON l.nurse_id = n.emp_id;
GO
/****** Object:  View [dbo].[vw_doctor_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_doctor_info] AS
SELECT d.emp_id, e.e_name, d.specilist, r.room_no
FROM doctor d
JOIN emp e ON d.emp_id = e.emp_id
JOIN room r ON d.room_no = r.room_no;
GO
/****** Object:  View [dbo].[vw_appointment_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_appointment_info] AS
SELECT a.patient_id, p.pname, a.appointment_id, a.date, d.emp_id AS doctor_id, e.e_name
FROM appointment a
JOIN patient p ON a.patient_id = p.patient_id
JOIN doctor d ON a.doctor_id = d.emp_id
join emp e on d.emp_id=e.emp_id;
GO
/****** Object:  View [dbo].[vw_insurance_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_insurance_info] AS
SELECT i.ins_no, i.patient_id, p.pname, i.maternity, i.optical, i.dental, ic.ins_code, ic.ins_company, ic.medical_coverage
FROM insurance i
JOIN patient p ON i.patient_id = p.patient_id
JOIN insurance_cover ic ON i.ins_code = ic.ins_code;
GO
/****** Object:  View [dbo].[vw_admission_info]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[vw_admission_info] AS
SELECT ad.admission_id, ad.patient_id, p.pname, ad.doctor_id AS doctor_id,e.e_name as doctor_name
, ad.nurse_id as nurse_id,en.e_name as nurse_name, ad.room_no, ad.date, ad.stay
FROM admission ad
JOIN patient p ON ad.patient_id = p.patient_id
JOIN doctor d ON ad.doctor_id = d.emp_id
join emp e on e.emp_id=d.emp_id
JOIN nurse n ON ad.nurse_id = n.emp_id
join emp en on en.emp_id=n.emp_id;
GO
/****** Object:  Table [dbo].[Bill]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Bill](
	[bill_no] [int] NOT NULL,
	[patient_id] [int] NOT NULL,
	[dec_charge] [int] NULL,
	[med_charge] [int] NULL,
	[room_charge] [int] NULL,
	[nursing_charge] [int] NULL,
	[lab_charge] [int] NULL,
	[advance] [int] NULL,
	[ins_no] [int] NULL,
	[ins_patient_id] [int] NULL,
	[total] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[bill_no] ASC,
	[patient_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[Bill_View]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Bill_View] AS
SELECT b.bill_no, b.patient_id, p.pname, b.dec_charge, b.med_charge, b.room_charge, 
      b.nursing_charge, b.lab_charge, b.advance, i.ins_no, i.maternity, i.optical, i.dental,b.total
FROM Bill b
JOIN Patient p ON b.patient_id = p.patient_id
LEFT JOIN Insurance i ON b.ins_no = i.ins_no AND b.ins_patient_id = i.patient_id;
GO
/****** Object:  View [dbo].[Lab_View]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Lab_View] AS
SELECT l.lab_no, l.patient_id, p.pname, l.test_type, l.high, l.wight, l.date, l.b_p_up,L.b_p_down, l.temp,
       l.test_code, tp.t_price,l.status, l.nurse_id, E.e_name AS nurse_name
FROM Lab l
JOIN Patient p ON l.patient_id = p.patient_id
JOIN Test_P tp ON l.test_code = tp.test_code
JOIN Nurse n ON l.nurse_id = n.emp_id
JOIN EMP E ON N.emp_id=E.emp_id;
GO
/****** Object:  View [dbo].[Room_View]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[Room_View] AS
SELECT r.room_no, r.dept_id, d.dept_name, r.status, r.catagory, rp.price
FROM Room r
JOIN Dept d ON r.dept_id = d.dept_id
JOIN Room_P rp ON r.catagory = rp.catagory;
GO
/****** Object:  View [dbo].[PatientDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[PatientDetails] AS
SELECT p.patient_id, p.pname, p.gender, p.paddress, p.age, p.phone_no,
       a.admission_id, a.doctor_id, a.nurse_id, a.room_no, a.date AS admission_date, a.stay,
       ap.appointment_id, ap.date AS appointment_date,
       l.lab_no, l.test_type, l.high, l.wight, l.date AS lab_date, l.temp
FROM patient p
LEFT JOIN admission a ON p.patient_id = a.patient_id
LEFT JOIN appointment ap ON p.patient_id = ap.patient_id
LEFT JOIN lab l ON p.patient_id = l.patient_id;
GO
/****** Object:  UserDefinedFunction [dbo].[GetPatientBillDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetPatientBillDetails](@patientID INT)
RETURNS TABLE
AS
RETURN
    SELECT b.bill_no, b.dec_charge, b.med_charge, b.room_charge,
           b.nursing_charge, b.lab_charge, b.advance,
           b.ins_no, b.ins_patient_id, ic.ins_company, ic.medical_coverage
    FROM Bill b
    LEFT JOIN Insurance i ON b.ins_no = i.ins_no AND b.ins_patient_id = i.patient_id
    LEFT JOIN Insurance_Cover ic ON i.ins_code = ic.ins_code
    WHERE b.patient_id = @patientID;
GO
/****** Object:  UserDefinedFunction [dbo].[GetDoctorDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetDoctorDetails] (@doctor_id INT)
RETURNS TABLE
AS
RETURN (
    SELECT emp.emp_id, emp.e_name, emp.age, emp.gender, emp.e_address, emp.phone_no,
           doctor.specilist, room.room_no
    FROM doctor
    INNER JOIN emp ON emp.emp_id = doctor.emp_id
    LEFT JOIN room ON doctor.room_no = room.room_no
    WHERE emp.emp_id = @doctor_id
);
GO
/****** Object:  UserDefinedFunction [dbo].[GetNurseDetails]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetNurseDetails] (@nurse_id INT)
RETURNS TABLE
AS
RETURN (
    SELECT emp.emp_id, emp.e_name, emp.age, emp.gender, emp.e_address, emp.phone_no,
           nurse.shift_t
    FROM nurse
    INNER JOIN emp ON emp.emp_id = nurse.emp_id
    WHERE emp.emp_id = @nurse_id
);
GO
/****** Object:  UserDefinedFunction [dbo].[GetLabDetailsForPatient]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [dbo].[GetLabDetailsForPatient](@patient_id INT)
RETURNS TABLE 
AS
RETURN 
    SELECT lab_no, test_type, high, wight, date,b_p_up,b_p_down, temp,status
    FROM lab
    WHERE patient_id  =@patient_id;
GO
/****** Object:  Table [dbo].[Hospital]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Hospital](
	[hospital_id] [int] NOT NULL,
	[h_name] [varchar](50) NULL,
	[h_city] [varchar](100) NULL,
	[h_contact] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[hospital_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Medicine]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Medicine](
	[med_Id] [int] NOT NULL,
	[med_name] [varchar](150) NULL,
	[med_type] [varchar](25) NULL,
	[med_desc] [varchar](150) NULL,
	[med_price] [int] NULL,
	[stock] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[med_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Medicine_report]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Medicine_report](
	[med_report_id] [int] NOT NULL,
	[med_Id] [int] NOT NULL,
	[company] [varchar](50) NULL,
	[quantity] [int] NULL,
	[box] [int] NULL,
	[prod_date] [smalldatetime] NULL,
	[expire_date] [date] NULL,
	[country] [varchar](50) NULL,
	[supplier_Id] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[med_report_id] ASC,
	[med_Id] ASC,
	[supplier_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Patient_Report]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Patient_Report](
	[report_Id] [int] NOT NULL,
	[patient_Id] [int] NOT NULL,
	[diagnosis] [varchar](50) NULL,
	[reference] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[report_Id] ASC,
	[patient_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Prescribed_Med]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Prescribed_Med](
	[Pres_med_Id] [int] NOT NULL,
	[Patient_Id] [int] NOT NULL,
	[Med_id] [int] NOT NULL,
	[Report_id] [int] NOT NULL,
	[quantity] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[Pres_med_Id] ASC,
	[Patient_Id] ASC,
	[Med_id] ASC,
	[Report_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Supplier]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Supplier](
	[Supplier_Id] [int] NOT NULL,
	[Supplier_name] [varchar](25) NULL,
	[phone] [varchar](150) NULL,
	[email] [varchar](50) NULL,
	[address] [varchar](50) NULL,
	[status] [varchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[Supplier_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
ALTER TABLE [dbo].[admission]  WITH CHECK ADD FOREIGN KEY([doctor_id])
REFERENCES [dbo].[doctor] ([emp_id])
GO
ALTER TABLE [dbo].[admission]  WITH CHECK ADD FOREIGN KEY([nurse_id])
REFERENCES [dbo].[nurse] ([emp_id])
GO
ALTER TABLE [dbo].[admission]  WITH CHECK ADD FOREIGN KEY([patient_id])
REFERENCES [dbo].[patient] ([patient_id])
GO
ALTER TABLE [dbo].[admission]  WITH CHECK ADD FOREIGN KEY([room_no])
REFERENCES [dbo].[room] ([room_no])
GO
ALTER TABLE [dbo].[appointment]  WITH CHECK ADD FOREIGN KEY([doctor_id])
REFERENCES [dbo].[doctor] ([emp_id])
GO
ALTER TABLE [dbo].[appointment]  WITH CHECK ADD FOREIGN KEY([patient_id])
REFERENCES [dbo].[patient] ([patient_id])
GO
ALTER TABLE [dbo].[Bill]  WITH CHECK ADD FOREIGN KEY([ins_no], [ins_patient_id])
REFERENCES [dbo].[insurance] ([ins_no], [patient_id])
GO
ALTER TABLE [dbo].[Bill]  WITH CHECK ADD FOREIGN KEY([patient_id])
REFERENCES [dbo].[patient] ([patient_id])
GO
ALTER TABLE [dbo].[Dept]  WITH CHECK ADD FOREIGN KEY([hospital_id])
REFERENCES [dbo].[Hospital] ([hospital_id])
GO
ALTER TABLE [dbo].[doctor]  WITH CHECK ADD FOREIGN KEY([emp_id])
REFERENCES [dbo].[emp] ([emp_id])
GO
ALTER TABLE [dbo].[doctor]  WITH CHECK ADD FOREIGN KEY([room_no])
REFERENCES [dbo].[room] ([room_no])
GO
ALTER TABLE [dbo].[emp]  WITH CHECK ADD FOREIGN KEY([dept_id])
REFERENCES [dbo].[Dept] ([dept_id])
GO
ALTER TABLE [dbo].[insurance]  WITH CHECK ADD FOREIGN KEY([ins_code])
REFERENCES [dbo].[insurance_cover] ([ins_code])
GO
ALTER TABLE [dbo].[insurance]  WITH CHECK ADD FOREIGN KEY([patient_id])
REFERENCES [dbo].[patient] ([patient_id])
GO
ALTER TABLE [dbo].[lab]  WITH CHECK ADD FOREIGN KEY([nurse_id])
REFERENCES [dbo].[nurse] ([emp_id])
GO
ALTER TABLE [dbo].[lab]  WITH CHECK ADD FOREIGN KEY([patient_id])
REFERENCES [dbo].[patient] ([patient_id])
GO
ALTER TABLE [dbo].[lab]  WITH CHECK ADD  CONSTRAINT [fk_l] FOREIGN KEY([test_code])
REFERENCES [dbo].[test_p] ([test_code])
GO
ALTER TABLE [dbo].[lab] CHECK CONSTRAINT [fk_l]
GO
ALTER TABLE [dbo].[Medicine_report]  WITH CHECK ADD FOREIGN KEY([med_Id])
REFERENCES [dbo].[Medicine] ([med_Id])
GO
ALTER TABLE [dbo].[Medicine_report]  WITH CHECK ADD FOREIGN KEY([supplier_Id])
REFERENCES [dbo].[Supplier] ([Supplier_Id])
GO
ALTER TABLE [dbo].[nurse]  WITH CHECK ADD FOREIGN KEY([emp_id])
REFERENCES [dbo].[emp] ([emp_id])
GO
ALTER TABLE [dbo].[Patient_Report]  WITH CHECK ADD FOREIGN KEY([patient_Id])
REFERENCES [dbo].[patient] ([patient_id])
GO
ALTER TABLE [dbo].[payroll]  WITH CHECK ADD FOREIGN KEY([emp_id])
REFERENCES [dbo].[emp] ([emp_id])
GO
ALTER TABLE [dbo].[Prescribed_Med]  WITH CHECK ADD FOREIGN KEY([Med_id])
REFERENCES [dbo].[Medicine] ([med_Id])
GO
ALTER TABLE [dbo].[Prescribed_Med]  WITH CHECK ADD FOREIGN KEY([Report_id], [Patient_Id])
REFERENCES [dbo].[Patient_Report] ([report_Id], [patient_Id])
GO
ALTER TABLE [dbo].[room]  WITH CHECK ADD FOREIGN KEY([catagory])
REFERENCES [dbo].[room_p] ([catagory])
GO
ALTER TABLE [dbo].[room]  WITH CHECK ADD FOREIGN KEY([dept_id])
REFERENCES [dbo].[Dept] ([dept_id])
GO
/****** Object:  StoredProcedure [dbo].[CalculateBillTotal]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[CalculateBillTotal]
    @patientID INT,
    @totalAmount INT OUTPUT
AS
BEGIN
    SELECT @totalAmount = SUM(dec_charge + med_charge + room_charge + nursing_charge + lab_charge)
    FROM Bill
    WHERE patient_id = @patientID
END
GO
/****** Object:  StoredProcedure [dbo].[DeleteBill]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[DeleteBill](
    @bill_no INT
)
AS
BEGIN
    DELETE FROM Bill
    WHERE bill_no = @bill_no;
END;
GO
/****** Object:  StoredProcedure [dbo].[DeleteEmployeeRecord]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[DeleteEmployeeRecord](
    @emp_id INT
)
AS
BEGIN
    DELETE FROM emp
    WHERE emp_id = @emp_id;
END;
GO
/****** Object:  StoredProcedure [dbo].[DeleteLabRecord]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[DeleteLabRecord](
    @lab_no INT,
    @patient_id INT
)
AS
BEGIN
    DELETE FROM lab
    WHERE lab_no = @lab_no AND patient_id = @patient_id;
END;
GO
/****** Object:  StoredProcedure [dbo].[DeletePatientRecord]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[DeletePatientRecord](
    @patient_id INT
)
AS
BEGIN
    DELETE FROM patient
    WHERE patient_id = @patient_id;
END;
GO
/****** Object:  StoredProcedure [dbo].[GeneratePatientReport]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[GeneratePatientReport]
    @patientID INT,
    @reportID INT OUTPUT,
    @diagnosis VARCHAR(50) OUTPUT,
    @reference VARCHAR(50) OUTPUT
AS
BEGIN
    SELECT @reportID = report_Id, @diagnosis = diagnosis, @reference = reference
    FROM Patient_Report
    WHERE patient_Id = @patientID
END
GO
/****** Object:  StoredProcedure [dbo].[InsertBill]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertBill](
    @bill_no INT,
    @patient_id INT,
    @dec_charge INT,
    @med_charge INT,
    @room_charge INT,
    @nursing_charge INT,
    @lab_charge INT,
    @advance INT,
    @ins_no INT,
    @ins_patient_id INT
)
AS
BEGIN
    INSERT INTO Bill (bill_no, patient_id, dec_charge, med_charge, room_charge,  nursing_charge, lab_charge, advance, ins_no, ins_patient_id)
    VALUES (@bill_no, @patient_id, @dec_charge, @med_charge, @room_charge,  @nursing_charge, @lab_charge, @advance, @ins_no, @ins_patient_id);
END;
GO
/****** Object:  StoredProcedure [dbo].[InsertDoctorWithoutRoom]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertDoctorWithoutRoom](
    @emp_id INT,
    @specialist VARCHAR(50)
)
AS
BEGIN
    INSERT INTO doctor (emp_id, specilist)
    VALUES (@emp_id, @specialist);
END;
GO
/****** Object:  StoredProcedure [dbo].[InsertDoctorWithRoom]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertDoctorWithRoom](
    @emp_id INT,
    @specialist VARCHAR(50),
    @room_no INT
)
AS
BEGIN
    INSERT INTO doctor (emp_id, specilist, room_no)
    VALUES (@emp_id, @specialist, @room_no);
END;
GO
/****** Object:  StoredProcedure [dbo].[InsertEmployeeRecord]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertEmployeeRecord](
    @emp_id INT,
    @e_name VARCHAR(50),
    @age INT,
    @gender VARCHAR(10),
    @e_address VARCHAR(100),
    @phone_no INT,
    @dept_id INT
)
AS
BEGIN
    INSERT INTO emp (emp_id, e_name, age, gender, e_address, phone_no, dept_id)
    VALUES (@emp_id, @e_name, @age, @gender, @e_address, @phone_no, @dept_id);
END;

GO
/****** Object:  StoredProcedure [dbo].[InsertLabRecord]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertLabRecord](
    @lab_no INT,
    @patient_id INT,
    @test_type INT,
    @high INT,
    @wight INT,
    @date DATE,
    @b_p_up INT,
	@b_p_down int,
    @temp INT,
    @test_code INT,
    @nurse_id INT
)
AS
BEGIN
    INSERT INTO lab (lab_no, patient_id, test_type, high, wight, date, b_p_up,b_p_down, temp, test_code, nurse_id)
    VALUES (@lab_no, @patient_id, @test_type, @high, @wight, @date, @b_p_up,@b_p_down, @temp, @test_code, @nurse_id);
END;
GO
/****** Object:  StoredProcedure [dbo].[InsertNurseWithoutShift]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertNurseWithoutShift](
    @emp_id INT
)
AS
BEGIN
    INSERT INTO nurse (emp_id)
    VALUES (@emp_id);
END;
GO
/****** Object:  StoredProcedure [dbo].[InsertNurseWithShift]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertNurseWithShift](
    @emp_id INT,
    @shift_t VARCHAR(50)
)
AS
BEGIN
    INSERT INTO nurse (emp_id, shift_t)
    VALUES (@emp_id, @shift_t);
END;
GO
/****** Object:  StoredProcedure [dbo].[InsertPatient]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertPatient]
    @patientID INT,
    @patientName VARCHAR(50),
    @gender VARCHAR(10),
    @address VARCHAR(100),
    @age INT,
    @phoneNo INT
AS
BEGIN
    INSERT INTO Patient (patient_id, pname, gender, paddress, age, phone_no)
    VALUES (@patientID, @patientName, @gender, @address, @age, @phoneNo)
END
GO
/****** Object:  StoredProcedure [dbo].[UpdateMedicinePrice]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[UpdateMedicinePrice]
    @medicineID INT,
    @newPrice INT
AS
BEGIN
    UPDATE Medicine
    SET med_price = @newPrice
    WHERE med_Id = @medicineID
END
GO
/****** Object:  StoredProcedure [dbo].[UpdateNurseShift]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[UpdateNurseShift]
    @emp_id int,
    @shift_t varchar(50)
AS
BEGIN
    UPDATE Nurse
    SET shift_t = @shift_t
    WHERE emp_id = @emp_id
END
GO
/****** Object:  StoredProcedure [dbo].[UpdateRoomStatus]    Script Date: 6/22/2023 7:19:54 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[UpdateRoomStatus]
    @roomNo INT,
    @newStatus VARCHAR(50)
AS
BEGIN
    UPDATE Room
    SET status = @newStatus
    WHERE room_no = @roomNo
END
GO
USE [master]
GO
ALTER DATABASE [hp] SET  READ_WRITE 
GO
