CREATE FUNCTION GetAppointmentDetails1 (@inputDate smallDATEtime, @doctorName VARCHAR(50))
RETURNS TABLE
AS
RETURN
(
  SELECT appointment_id, date, patient_id
  FROM appointment
  WHERE date = @inputDate
    AND doctor_id IN (
      SELECT d.emp_id
      FROM doctor d 
	  join emp e on d.emp_id=e.emp_id
      WHERE e.e_name = @doctorName
    )
);
SELECT *
FROM GetAppointmentDetails1('2023-06-21 10:00:00', 'John Smith');


CREATE FUNCTION GetAppointmentDetails_patient(@patientId INT, @appointmentId INT)
RETURNS TABLE
AS
RETURN
(
    SELECT *
    FROM appointment
    WHERE patient_id = @patientId AND appointment_id = @appointmentId
);
SELECT * FROM GetAppointmentDetails_patient(1, 1);

CREATE FUNCTION GetAppointmentsByDate(@appointmentDate DATE)
RETURNS TABLE
AS
RETURN
    SELECT a.appointment_id, a.patient_id, p.pname, a.date, a.doctor_id
    FROM Appointment a
    JOIN Patient p ON a.patient_id = p.patient_id
    WHERE CONVERT(DATE, a.date) = @appointmentDate;

CREATE FUNCTION GetDoctorAppointments(@doctorName VARCHAR(50))
RETURNS TABLE
AS
RETURN
    SELECT a.appointment_id, a.patient_id, p.pname, a.date
    FROM Appointment a
    JOIN Patient p ON a.patient_id = p.patient_id
    JOIN Doctor d ON a.doctor_id = d.emp_id
	join emp e on d.emp_id=e.emp_id
    WHERE e.e_name = @doctorName;
CREATE FUNCTION GetPatientDetails(@patientID INT)
RETURNS TABLE
AS
RETURN
    SELECT a.appointment_id, a.date AS appointment_date, d.emp_id AS doctor_id, e.e_name AS doctor_name,
           ad.admission_id, ad.date AS admission_date, ad.room_no
    FROM Appointment a
    LEFT JOIN Admission ad ON a.patient_id = ad.patient_id
    LEFT JOIN Doctor d ON a.doctor_id = d.emp_id
	join emp e on e.emp_id=d.emp_id
    LEFT JOIN Room r ON ad.room_no = r.room_no
    WHERE a.patient_id = @patientID;

CREATE FUNCTION GetPatientBillDetails(@patientID INT)
RETURNS TABLE
AS
RETURN
    SELECT b.bill_no, b.dec_charge, b.med_charge, b.room_charge,
           b.nursing_charge, b.lab_charge, b.advance,
           b.ins_no, b.ins_patient_id, ic.ins_company, ic.medical_coverage
    FROM Bill b
    LEFT JOIN Insurance i ON b.ins_no = i.ins_no AND b.ins_patient_id = i.patient_id
    LEFT JOIN Insurance_Cover ic ON i.ins_code = ic.ins_code
    WHERE b.patient_id = @patientID;

CREATE FUNCTION GetTotalPatientsInDepartment
    (@departmentName VARCHAR(50))
RETURNS INT
AS
BEGIN
    DECLARE @totalCount INT

    SELECT @totalCount = COUNT(DISTINCT patient_id)
    FROM Admission
    JOIN Doctor ON Admission.doctor_id = Doctor.emp_id
	join emp e on e.emp_id=doctor.emp_id
    JOIN Dept ON e.dept_id = Dept.dept_id
    WHERE Dept.dept_name = @departmentName

    RETURN @totalCount
END


CREATE FUNCTION GetMedicinePrice
    (@medicineID INT)
RETURNS INT
AS
BEGIN
    DECLARE @price INT

    SELECT @price = med_price
    FROM Medicine
    WHERE med_Id = @medicineID

    RETURN @price
END

CREATE FUNCTION GetTotalAdmissionsByDate
    (@date DATE)
RETURNS INT
AS
BEGIN
    DECLARE @totalCount INT

    SELECT @totalCount = COUNT(*)
    FROM Admission
    WHERE CONVERT(DATE, date) = @date

    RETURN @totalCount
END
CREATE FUNCTION GetDoctorDetails (@doctor_id INT)
RETURNS TABLE
AS
RETURN (
    SELECT emp.emp_id, emp.e_name, emp.age, emp.gender, emp.e_address, emp.phone_no,
           doctor.specilist, room.room_no
    FROM doctor
    INNER JOIN emp ON emp.emp_id = doctor.emp_id
    LEFT JOIN room ON doctor.room_no = room.room_no
    WHERE emp.emp_id = @doctor_id
);
CREATE FUNCTION GetNurseDetails (@nurse_id INT)
RETURNS TABLE
AS
RETURN (
    SELECT emp.emp_id, emp.e_name, emp.age, emp.gender, emp.e_address, emp.phone_no,
           nurse.shift_t
    FROM nurse
    INNER JOIN emp ON emp.emp_id = nurse.emp_id
    WHERE emp.emp_id = @nurse_id
);

