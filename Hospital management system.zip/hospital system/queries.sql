select * from EmployeeDetails
select * from PatientDetails
select * from vw_insurance_info
---procedure
DECLARE @reportID INT;
DECLARE @diagnosis VARCHAR(50);
DECLARE @reference VARCHAR(50);

EXEC GeneratePatientReport @patientID = 1, @reportID = @reportID OUTPUT, @diagnosis = @diagnosis OUTPUT, @reference = @reference OUTPUT;

SELECT @reportID AS ReportID, @diagnosis AS Diagnosis, @reference AS Reference;
---procedure
DECLARE @totalAmount INT;

EXEC CalculateBillTotal @patientID = 1, @totalAmount = @totalAmount OUTPUT;

SELECT @totalAmount AS TotalAmount;
---procedure
EXEC InsertPatient @patientID = 11, @patientName = 'John Doe', @gender = 'Male', @address = '123 Main St', @age = 30, @phoneNo = 1234567890;
---procedure
EXEC UpdateRoomStatus @roomNo = 101, @newStatus = 'Occupied';
---procedure
EXEC UpdateNurseShift @emp_id = 14, @shift_t = 'Night Shift';
---procedure
EXEC InsertEmployeeRecord @emp_id = 21, @e_name = 'Jane Smith', @age = 35, @gender = 'Female', @e_address = '456 Elm St', @phone_no = 9876543210, @dept_id = 1;
---procedure
EXEC InsertLabRecord @lab_no = 11, @patient_id = 123, @test_type = 1, @high = 160, @wight = 70, @date = '2023-06-21', @b_p_up = 120, @b_p_down = 80, @temp = 98, @test_code = 1234, @nurse_id = 456;
---procedure
EXEC DeleteLabRecord @lab_no = 11, @patient_id = 123;
---procedure
EXEC DeleteBill @bill_no = 11;
---procedure
EXEC InsertDoctorWithRoom @emp_id = 22, @specialist = 'Cardiology', @room_no = 101;


---functions
SELECT *
FROM GetAppointmentDetails1('2023-06-21 10:00:00', 'John Smith');
---functions
SELECT *
FROM GetAppointmentDetails_patient(1, 1);
---functions
SELECT *
FROM GetAppointmentsByDate('2023-06-21');
---functions
SELECT *
FROM GetDoctorAppointments('John Smith');
---functions
SELECT *
FROM GetPatientDetails(1);
---functions
SELECT *
FROM GetPatientBillDetails(1);
---functions
SELECT dbo.GetTotalPatientsInDepartment('Cardiology');
---functions
SELECT dbo.GetMedicinePrice(3);
---functions
SELECT dbo.GetTotalAdmissionsByDate('2023-06-21');
---functions
SELECT *
FROM GetDoctorDetails(4);
---functions
SELECT *
FROM GetNurseDetails(11);
---functions
select * from GetLabDetailsForPatient(1)



