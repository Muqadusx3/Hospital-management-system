CREATE PROCEDURE GeneratePatientReport
    @patientID INT,
    @reportID INT OUTPUT,
    @diagnosis VARCHAR(50) OUTPUT,
    @reference VARCHAR(50) OUTPUT
AS
BEGIN
    SELECT @reportID = report_Id, @diagnosis = diagnosis, @reference = reference
    FROM Patient_Report
    WHERE patient_Id = @patientID
END


CREATE PROCEDURE CalculateBillTotal
    @patientID INT,
    @totalAmount INT OUTPUT
AS
BEGIN
    SELECT @totalAmount = SUM(dec_charge + med_charge + room_charge + nursing_charge + lab_charge)
    FROM Bill
    WHERE patient_id = @patientID
END

CREATE PROCEDURE InsertPatient
    @patientID INT,
    @patientName VARCHAR(50),
    @gender VARCHAR(10),
    @address VARCHAR(100),
    @age INT,
    @phoneNo INT
AS
BEGIN
    INSERT INTO Patient (patient_id, pname, gender, paddress, age, phone_no)
    VALUES (@patientID, @patientName, @gender, @address, @age, @phoneNo)
END

CREATE PROCEDURE UpdateRoomStatus
    @roomNo INT,
    @newStatus VARCHAR(50)
AS
BEGIN
    UPDATE Room
    SET status = @newStatus
    WHERE room_no = @roomNo
END

CREATE PROCEDURE UpdateNurseShift
    @emp_id int,
    @shift_t varchar(50)
AS
BEGIN
    UPDATE Nurse
    SET shift_t = @shift_t
    WHERE emp_id = @emp_id
END

CREATE PROCEDURE InsertEmployeeRecord(
    @emp_id INT,
    @e_name VARCHAR(50),
    @age INT,
    @gender VARCHAR(10),
    @e_address VARCHAR(100),
    @phone_no INT,
    @dept_id INT
)
AS
BEGIN
    INSERT INTO emp (emp_id, e_name, age, gender, e_address, phone_no, dept_id)
    VALUES (@emp_id, @e_name, @age, @gender, @e_address, @phone_no, @dept_id);
END;

CREATE PROCEDURE InsertLabRecord(
    @lab_no INT,
    @patient_id INT,
    @test_type INT,
    @high INT,
    @wight INT,
    @date DATE,
    @b_p_up INT,
	@b_p_down int,
    @temp INT,
    @test_code INT,
    @nurse_id INT
)
AS
BEGIN
    INSERT INTO lab (lab_no, patient_id, test_type, high, wight, date, b_p_up,b_p_down, temp, test_code, nurse_id)
    VALUES (@lab_no, @patient_id, @test_type, @high, @wight, @date, @b_p_up,@b_p_down, @temp, @test_code, @nurse_id);
END;

CREATE PROCEDURE DeleteLabRecord(
    @lab_no INT,
    @patient_id INT
)
AS
BEGIN
    DELETE FROM lab
    WHERE lab_no = @lab_no AND patient_id = @patient_id;
END;
CREATE PROCEDURE DeleteEmployeeRecord(
    @emp_id INT
)
AS
BEGIN
    DELETE FROM emp
    WHERE emp_id = @emp_id;
END;
CREATE PROCEDURE DeletePatientRecord(
    @patient_id INT
)
AS
BEGIN
    DELETE FROM patient
    WHERE patient_id = @patient_id;
END;
CREATE PROCEDURE InsertDoctorWithRoom(
    @emp_id INT,
    @specialist VARCHAR(50),
    @room_no INT
)
AS
BEGIN
    INSERT INTO doctor (emp_id, specilist, room_no)
    VALUES (@emp_id, @specialist, @room_no);
END;
CREATE PROCEDURE InsertDoctorWithoutRoom(
    @emp_id INT,
    @specialist VARCHAR(50)
)
AS
BEGIN
    INSERT INTO doctor (emp_id, specilist)
    VALUES (@emp_id, @specialist);
END;
CREATE PROCEDURE InsertNurseWithShift(
    @emp_id INT,
    @shift_t VARCHAR(50)
)
AS
BEGIN
    INSERT INTO nurse (emp_id, shift_t)
    VALUES (@emp_id, @shift_t);
END;
CREATE PROCEDURE InsertNurseWithoutShift(
    @emp_id INT
)
AS
BEGIN
    INSERT INTO nurse (emp_id)
    VALUES (@emp_id);
END;
CREATE PROCEDURE InsertBill(
    @bill_no INT,
    @patient_id INT,
    @dec_charge INT,
    @med_charge INT,
    @room_charge INT,
    @nursing_charge INT,
    @lab_charge INT,
    @advance INT,
    @ins_no INT,
    @ins_patient_id INT
)
AS
BEGIN
    INSERT INTO Bill (bill_no, patient_id, dec_charge, med_charge, room_charge,  nursing_charge, lab_charge, advance, ins_no, ins_patient_id)
    VALUES (@bill_no, @patient_id, @dec_charge, @med_charge, @room_charge,  @nursing_charge, @lab_charge, @advance, @ins_no, @ins_patient_id);
END;

CREATE PROCEDURE DeleteBill(
    @bill_no INT
)
AS
BEGIN
    DELETE FROM Bill
    WHERE bill_no = @bill_no;
END;

