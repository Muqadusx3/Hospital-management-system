CREATE TRIGGER UpdateSupplierStatus
ON Medicine_report
AFTER INSERT, DELETE
AS
BEGIN
    UPDATE Supplier
    SET status = 'Active'
    WHERE supplier_Id IN (SELECT supplier_Id FROM inserted)

    IF NOT EXISTS (SELECT supplier_Id FROM Medicine_report WHERE supplier_Id IN (SELECT supplier_Id FROM Supplier))
    BEGIN
        UPDATE Supplier
        SET status = 'Inactive'
        WHERE supplier_Id IN (SELECT supplier_Id FROM deleted)
    END
END

CREATE TRIGGER CheckInsuranceExpiryOnBill
ON Bill
AFTER INSERT
AS
BEGIN
    DECLARE @patientId INT, @insuranceNo INT
	declare @expiryDate smallDATEtime

	select @expiryDate expire_date from insurance
    SELECT @patientId = patient_id, @insuranceNo = ins_no
    FROM inserted
    WHERE patient_id IS NOT NULL AND ins_no IS NOT NULL 
	
    IF @expiryDate <= GETDATE()
    BEGIN
        -- Raise an error or perform an action when insurance is expired
        RAISERROR('Cannot create bill for Patient ID: %d. Insurance No: %d is expired.', 16, 1, @patientId, @insuranceNo)
        
    END
END
CREATE TRIGGER UpdateDepartmentStats
ON Emp
AFTER INSERT, DELETE
AS
BEGIN
    UPDATE Dept
    SET total_emp = (SELECT COUNT(*) FROM Emp WHERE Dept.dept_id = Emp.dept_id)
    FROM Dept
    INNER JOIN inserted ON Dept.dept_id = inserted.dept_id

    UPDATE Dept
    SET total_emp = (SELECT COUNT(*) FROM Emp WHERE Dept.dept_id = Emp.dept_id)
    FROM Dept
    INNER JOIN deleted ON Dept.dept_id = deleted.dept_id
END
CREATE TRIGGER UpdateInsuranceCoverage
ON Bill
AFTER INSERT
AS
BEGIN
    UPDATE Insurance
    SET remaing_med_amount = remaing_med_amount - (SELECT total FROM inserted WHERE patient_id = Insurance.patient_id)
    FROM Insurance
    INNER JOIN inserted ON Insurance.patient_id = inserted.patient_id
END
CREATE TRIGGER UpdateMedicineStock
ON Prescribed_Med
AFTER INSERT
AS
BEGIN
    UPDATE Medicine
    SET stock = stock - (SELECT quantity FROM inserted WHERE Med_id = Medicine.med_Id)
    FROM Medicine
    INNER JOIN inserted ON Medicine.med_Id = inserted.Med_id
END

CREATE TRIGGER CalculateBillAmount
ON Bill
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE Bill
    SET total = b.dec_charge + b.med_charge + b.room_charge  + b.nursing_charge + b.lab_charge
    FROM Bill b
    INNER JOIN inserted ON B.bill_no = inserted.bill_no
END
CREATE TRIGGER UpdateRoomStatus
ON Admission
AFTER INSERT, UPDATE
AS
BEGIN
    UPDATE Room
    SET status = 'Occupied'
    WHERE room_no IN (SELECT room_no FROM inserted)

    UPDATE Room
    SET status = 'Available'
    WHERE room_no IN (SELECT room_no FROM deleted)
        AND room_no NOT IN (SELECT room_no FROM Admission)
END
CREATE TRIGGER CalculateRoomChargesOnBill
ON Bill
AFTER INSERT
AS
BEGIN
    UPDATE Bill
    SET room_charge = A.stay * Rp.price
    FROM Bill B
    INNER JOIN Admission A ON B.patient_id = A.patient_id
    INNER JOIN Room R ON A.room_no = R.room_no
	join room_p rp on r.catagory=rp.catagory
    WHERE B.bill_no IN (SELECT bill_no FROM inserted)
END

CREATE TRIGGER CalculateLabChargesOnBill
ON Bill
AFTER INSERT
AS
BEGIN
    UPDATE B
    SET lab_charge =  TP.t_price
    FROM Bill B
    INNER JOIN Lab L ON B.patient_id = L.patient_id
    INNER JOIN Test_p TP ON L.test_code = TP.test_code
    WHERE B.bill_no IN (SELECT bill_no FROM inserted)
END
CREATE TRIGGER CalculateMedicineChargesOnBill
ON Bill
AFTER INSERT
AS
BEGIN
    UPDATE B
    SET med_charge = PM.quantity * M.med_price
    FROM Bill B
    INNER JOIN Prescribed_Med PM ON B.patient_id = PM.Patient_Id
    INNER JOIN Medicine M ON PM.Med_id = M.med_Id
    WHERE B.bill_no IN (SELECT bill_no FROM inserted)
END
