create table Hospital(
hospital_id int not null primary key,
h_name varchar(50),
h_city varchar(100),
h_contact int
);
create table patient(
patient_id int primary key,
pname varchar(50),
gender varchar(10),
paddress varchar(100),
age int,
phone_no int
);
create table Dept(
dept_id int not null primary key,
dept_name varchar(50),
hospital_id int foreign key references hospital(hospital_id)
);
create table emp(
emp_id int primary key,
e_name varchar(50),
age int,
gender varchar(10),
e_address varchar(100),
phone_no int,
dept_id int foreign key references dept(dept_id),
status varchar(50)
);
create table payroll (
payroll_id int not null,
emp_id int not null foreign key references emp(emp_id),
salary int,
bouns int,
account_no int,
constraint pk primary key(payroll_id,emp_id)
);
create table room_p(
catagory varchar(50) primary key,
price int,
);
create table room(
room_no int primary key,
dept_id int foreign key references dept(dept_id),
status varchar(50),
catagory varchar(50) foreign key references room_p(catagory),
);
create table test_p(
test_code int primary key,
t_price int
);
create table nurse(
emp_id int not null foreign key references emp(emp_id) primary key,
shift_t varchar(50)
);
create table lab(
lab_no int not null ,
patient_id int not null foreign key references patient(patient_id),
test_type int,
high int,
wight int,
date date,
b_p int,
temp int,
test_code int foreign key references test_p(test_code),
nurse_id int foreign key references nurse(emp_id),
constraint pk_l primary key(lab_no,patient_id)
);
create table doctor(
emp_id int not null foreign key references emp(emp_id) primary key,
specilist varchar(50),
room_no int foreign key references room(room_no)
);


create table appointment(
patient_id int not null foreign key references patient(patient_id),
appointment_id int not null,
date smalldatetime,
doctor_id int foreign key references doctor(emp_id),
constraint pk_p primary key (patient_id,appointment_id)
);
create table admission(
admission_id int not null,
patient_id int not null foreign key references patient(patient_id),
doctor_id int foreign key references doctor(emp_id),
nurse_id int foreign key references nurse(emp_id),
room_no int foreign key references room(room_no),
date smalldatetime,
stay int,
constraint pk_a primary key (patient_id,admission_id)
);

create table insurance_cover(
ins_code int primary key,
ins_company varchar(50),
medical_coverage int
);
create table insurance(
ins_no int ,
patient_id int foreign key references patient(patient_id),
maternity varchar(10),
optical varchar(10),
dental varchar(10),
ins_code int foreign key references insurance_cover(ins_code)
constraint pk_i primary key (patient_id,ins_no)
);
create table Bill(
bill_no int,
patient_id int FOREIGN KEY REFERENCES patient(patient_Id),
dec_charge int ,
med_charge int,
room_charge int,
operation_charge int,
no_of_day varchar (50),
nursing_charge int,
lab_charge int,
advance int,
ins_no int ,
ins_patient_id int ,
foreign key(ins_no,ins_patient_id) references insurance(ins_no,patient_id),
primary key(bill_no,patient_id)
);
alter table insurance 
drop constraint pk_i 
alter table insurance 
add constraint pk1 primary key(ins_no,patient_id)
alter table bill
add constraint fk1 foreign key(ins_no,ins_patient_id) references insurance(ins_no,patient_id)
create table Supplier(
Supplier_Id int PRIMARY KEY,
Supplier_name varchar(25),
phone varchar(150),
email varchar(50),
address varchar(50)
);

create table Medicine(
med_Id int PRIMARY KEY,
med_name varchar(150),
med_type varchar(25),
med_desc varchar(150),
med_price int ,
);
create table Medicine_report(
med_report_id int ,
med_Id int FOREIGN KEY REFERENCES medicine(med_Id),
company varchar (50),
quantity int,
box int,
prod_date smalldatetime,
expire_date date,
country varchar (50),
supplier_Id int FOREIGN KEY REFERENCES supplier(supplier_Id),
primary key(med_report_id,med_id,supplier_id)
)
create table Patient_Report(
report_Id int ,
patient_Id int  FOREIGN KEY REFERENCES patient(patient_Id),
diagnosis varchar(50),
reference varchar(50),
primary key (report_id,patient_id)
)
create table Prescribed_Med(
Pres_med_Id int,
Patient_Id int,
Med_id int FOREIGN KEY REFERENCES medicine(med_Id),
Report_id int,
FOREIGN KEY(report_Id,patient_id) REFERENCES patient_report(report_Id,patient_id),
primary key (pres_med_id,patient_id,med_id,report_id)
)



